PIVOT2D README

\havoc2d_collide: PIVOT2D library

Create library out of files in the directory. Example files will need to be linked to this library and the \havoc2d_collide directory will need to be added to the include path. This library depends on the HAVOC2D library as well.

\havoc2d_collide_example
\deform_collide
\wavy_collide    : examples using the PIVOT2D library

Compile all files in the directory and link to the PIVOT2D library.

