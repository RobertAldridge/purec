HAVOC3D example program

- create a project that includes all of these files
- link with the HAVOC3D, opengl, and glut libraries
- set the include directories for the HAVOC3D library directory