HAVOC3D: main 3D Voronoi diagram library

- compile all files in this directory into a library
- link with the opengl library
