/******************************************************************
*
*	CyberX3D for C++
*
*	Copyright (C) Satoshi Konno 1996-2002
*
*	File:	PointingDeviceSensorNode.h
*
******************************************************************/

#ifndef _CX3D_POINTINGDEVICENODE_H_
#define _CX3D_POINTINGDEVICENODE_H_

#include <cybergarage/x3d/SensorNode.h>

namespace CyberX3D
{

	class PointingDeviceSensorNode : public SensorNode
	{
	
	public:
	
		PointingDeviceSensorNode()
		{
		}
		
		virtual ~PointingDeviceSensorNode()
		{
		}
		
	};
	
}

#endif

