/******************************************************************
*
*	CyberX3D for C++
*
*	Copyright (C) Satoshi Konno 1996-2002
*
*	File:	Geometry2DNode.h
*
******************************************************************/

#ifndef _CV97_GEOMETRY2DNODE_H_
#define _CV97_GEOMETRY2DNODE_H_

#include <cybergarage/x3d/GeometryNode.h>

namespace CyberX3D
{

	class Geometry2DNode : public GeometryNode
	{
	
	public:
	
		Geometry2DNode();
		virtual ~Geometry2DNode();
		
	};
	
}

#endif
