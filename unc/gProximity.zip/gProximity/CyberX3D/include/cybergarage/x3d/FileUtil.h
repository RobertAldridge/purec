/******************************************************************
*
*	CyberVRML97 for C++
*
*	Copyright (C) Satoshi Konno 1996-2002
*
*	File:	FileUtil.h
*
******************************************************************/

#ifndef _CV97_FILEUTIL_H_
#define _CV97_FILEUTIL_H_

namespace CyberX3D
{

	enum
	{
		FILE_FORMAT_NONE,
		FILE_FORMAT_VRML,
		FILE_FORMAT_XML,
		FILE_FORMAT_X3D,
		FILE_FORMAT_GIF,
		FILE_FORMAT_JPEG,
		FILE_FORMAT_TARGA,
		FILE_FORMAT_PNG
	};
	
	int GetFileFormat(const char *filename);
	
}

#endif
