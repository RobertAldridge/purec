/******************************************************************
*
*	CyberX3D for C++
*
*	Copyright (C) Satoshi Konno 1996-2003
*
*	File: CyberX3D.h
*
******************************************************************/

#ifndef _CYBERX3D_H_
#define _CYBERX3D_H_

#include <cybergarage/x3d/CyberX3DConfig.h>
#include <cybergarage/x3d/SceneGraph.h>

#endif
