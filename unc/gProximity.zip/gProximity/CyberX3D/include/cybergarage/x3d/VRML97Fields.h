/******************************************************************
*
*	CyberVRML97 for C++
*
*	Copyright (C) Satoshi Konno 1996-2002
*
*	File:	VRML97Fields.h
*
******************************************************************/

#ifndef _CV97_VRML97FIELDS_H_
#define _CV97_VRML97FIELDS_H_

#include <cybergarage/x3d/Field.h>
#include <cybergarage/x3d/SFBool.h>
#include <cybergarage/x3d/SFVec2f.h>
#include <cybergarage/x3d/SFVec3f.h>
#include <cybergarage/x3d/SFColor.h>
#include <cybergarage/x3d/SFRotation.h>
#include <cybergarage/x3d/SFMatrix.h>
#include <cybergarage/x3d/SFString.h>
#include <cybergarage/x3d/SFTime.h>
#include <cybergarage/x3d/SFInt32.h>
#include <cybergarage/x3d/SFFloat.h>
#include <cybergarage/x3d/SFImage.h>
#include <cybergarage/x3d/SFNode.h>

#include <cybergarage/x3d/MField.h>
#include <cybergarage/x3d/MFVec2f.h>
#include <cybergarage/x3d/MFVec3f.h>
#include <cybergarage/x3d/MFColor.h>
#include <cybergarage/x3d/MFRotation.h>
#include <cybergarage/x3d/MFInt32.h>
#include <cybergarage/x3d/MFTime.h>
#include <cybergarage/x3d/MFFloat.h>
#include <cybergarage/x3d/MFString.h>

#endif

