/******************************************************************
*
*	CyberX3D for C++
*
*	Copyright (C) Satoshi Konno 1996-2003
*
*	File: CyberX3DConfig.h
*
******************************************************************/

#ifndef _CYBERX3DCONFIG_H_
#define _CYBERX3DCONFIG_H_

#ifdef HAVE_CONFIG_H

#include "config.h"

#endif

#endif
