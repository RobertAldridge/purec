/******************************************************************
*
*	CyberX3D for C++
*
*	Copyright (C) Satoshi Konno 1996-2002
*
*	File:	NetworkSensorNode.cpp
*
*	11/15/02
*		- The first revision.
*
******************************************************************/

#include <cybergarage/x3d/NetworkSensorNode.h>

using namespace CyberX3D;

NetworkSensorNode::NetworkSensorNode()
{
}

NetworkSensorNode::~NetworkSensorNode()
{
}
