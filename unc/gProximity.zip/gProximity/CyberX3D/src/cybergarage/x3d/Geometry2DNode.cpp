/******************************************************************
*
*	CyberX3D for C++
*
*	Copyright (C) Satoshi Konno 1996-2002
*
*	File:	Geometry2DNode.cpp
*
******************************************************************/

#include <cybergarage/x3d/Geometry2DNode.h>

using namespace CyberX3D;

Geometry2DNode::Geometry2DNode()
{
}

Geometry2DNode::~Geometry2DNode()
{
}
