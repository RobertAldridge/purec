V-Collide release 2.01
  Copyright (c) University of North Carolina

hello_world -- simple and simple2:
---------------------------------

This is a very simple demo, intended to demonstrate the
basic functionality of V-Collide. The demo consists of two
unit cubes, each moving along the X axis towards the other
and finally colliding and crossing each other.

In the simple demo, the program just reports which are the
intersecting objects, and in the simple2 demo, the intersecting
triangles of each pair of intersecting objects are also
reported.


USAGE:
-----
simple

simple2


